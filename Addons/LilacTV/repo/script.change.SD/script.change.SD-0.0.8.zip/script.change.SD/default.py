# -*- coding: utf-8 -*-
import sys
import os
import time
import json
import xbmc
import xbmcgui

def dis_or_enable_addon(addon_id, enable):
    addon = '"%s"' % addon_id
    do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}' % (addon, enable)
    query = xbmc.executeJSONRPC(do_json)
    response = json.loads(query)
    if enable == "true":
        xbmc.log("### Enabled %s, response = %s" % (addon_id, response))
    else:
        xbmc.log("### Disabled %s, response = %s" % (addon_id, response))
    return xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))

def restartPVR():
    dis_or_enable_addon("pvr.vdr.vnsi", "true")
    time.sleep(2)
    dis_or_enable_addon("pvr.vdr.vnsi", "false")

if __name__=='__main__':

    dialog = xbmcgui.Dialog()
    yes = dialog.yesno("TV채널 업데이트", "", "채널 정보를 다시 불러 옵니다.")
    if yes:
        xbmc.executebuiltin('ActivateWindow(TVChannels)')
        time.sleep(1)
        condition = xbmc.getCondVisibility('Player.HasMedia')
        if condition:
            xbmc.executebuiltin("PlayerControl(Stop)")
            time.sleep(1)
       
        restartPVR()
