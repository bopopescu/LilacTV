# plugin.video.kayo.sports

Unofficial 3rd Party Kayo Sports plugin for Kodi.

https://www.matthuisman.nz/2019/03/kayo-sports-kodi-add-on.html
