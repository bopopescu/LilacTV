from resources.lib.constants import SERVICE_TIME
from resources.lib.matthuisman.service import run

run(SERVICE_TIME)